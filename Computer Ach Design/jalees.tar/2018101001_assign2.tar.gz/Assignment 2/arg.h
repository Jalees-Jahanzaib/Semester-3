int input( char *s);
