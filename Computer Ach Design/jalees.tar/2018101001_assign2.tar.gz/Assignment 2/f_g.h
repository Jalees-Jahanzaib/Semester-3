int fg(char *s,char *q,int t);
