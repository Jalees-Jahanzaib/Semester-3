
EXECUTING SHELL:
    1.To run first go to  the folder which all the .c and .h file.
    2.Type "make install" to run the shell
    3.Now from any directory u can run "./shell" 


1.shell1.c
    This has the main func which find the ~ and loop for taking input continuously.

2.arg1.c
    This has "input" func which divide the command on ; and store ach command in 2d string array.
3.map1.c
    This has "commnd" func which check which has be given as input.
4.pwd1.c
    Print absolute path  of the current working directory.
5.ls_exe1.c
    This has "ls" func whicjh implements "ls" command along with various flag.
6.display1.c
    Print prompt.
7.info1.c 
    Implement pinfo command.
8.f_g1.c
    Contains execvp command to execcute commands like vim ,emacs etc.                       
