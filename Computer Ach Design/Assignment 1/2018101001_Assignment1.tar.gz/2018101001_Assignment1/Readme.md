This readme file is for Q1 and Q2 of Assignment1:
Q1
Inputs: Only one input is taken i.e File to be reversed;
        any extra or less no of inputs will result in error;
        All the error handling is duly done.if the file name does not exist it returns an error.if the file fails to be read it returns an error.It creates a Folder named "Assignment" with permissions 700 and a file(Reverse.txt) inside it with permissions 600; 
Process:The code takes large chunkes of the file (size 1e5 ) and reverses them and            then writes them in "Reverse.txt".A percentage bar is also displayed while            the file is reversing;


Q2
Inputs: 3 Inputs are taken. Newfile ,Oldfile and the Directory.Any extra or less no           of inputs will result in error.All the error handling is duly done.if any of          the file name does not exist it returns an error.if the file fails to be read         it returns an NO.
Process:The code checks permissions for each of the files (Newfile ,Oldfile and the            Directory) and lists there permission for USER,GROUP and OTHERS.It also               lists wheather each of the above stated files exists or not;
Checking Wheather the files are Reverse of each other?
         The code takes one pointer at the end of one file one at the starting of one file.and compares the strings;
         .A percentage bar is also displayed while the code is  is checking wheather the  files are reverse of each other;




