#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <unistd.h>
#include <limits.h>
#include <errno.h>
#include <sys/utsname.h>
#include "display.h"
#include "arg.h"
#include "shell.h"
#include <sys/types.h>
#include <unistd.h>
#include<sys/wait.h>


int main();
int  loop();
char path_name[20000];
int piid;

int msize=1020;
char * p_name[1020];
int p_num[1020];
int main()
{
    for(int i=0;i<msize;i++)
    {
        p_num[i]=-1;
    }
     
    piid=getpid();
    char filename[1000];
    sprintf(filename,"/proc/%d/exe",piid);
    char path[2000];
    if(readlink(filename,path,63)==-1)
    {
        printf("Error:unable to find executable\n");
        return 0;
    }

    strncpy(path_name,path,strlen(path)-6);

    loop();
    return 0;
}
int  loop()
{
    
    char str[20000];

    do{
        int pid,pid_status;
        while((pid=waitpid(-1,&pid_status, WNOHANG | WUNTRACED))>0)
        {
            if(WIFEXITED(pid_status)){
                for(int i=0;i<msize;i++)
                {
                    if(p_num[i]==pid)
                    {
                        
                        printf("%s with pid %d exited normally.\n",p_name[i],p_num[i]);
                        p_num[i]=-1;
                        break;
                    }
                }
            }
        }
        break;
    }while(1==1);

    dis(path_name);


    
    fgets(str,2000,stdin);
    
    input(str);

    loop();
    return 0;    
    
}