extern char path_name[20000];
extern int piid;

extern int p_num[1020];
extern char * p_name[1020];
extern int msize;