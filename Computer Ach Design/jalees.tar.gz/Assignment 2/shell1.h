extern char path_name[20002];
extern int piid;

extern int p_num[1022];
extern char * p_name[1022];
extern int msize;