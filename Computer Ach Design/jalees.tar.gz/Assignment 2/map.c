#include<stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <errno.h>
#include <sys/utsname.h>
#include<string.h>
#include "map.h"
#include "pwd.h"
#include "shell.h"
#include "info.h"
#include "f_g.h"

#include "ls_exe.h"
int command(char s[][200],int count)
{
    
    for(int i=0;i<count;i++)
    {
        char ans[200];
        strcpy(ans,s[i]);
        int len=0;
        char str[100][200];
        int index=0;
        for(char *p = strtok(s[i]," "); p != NULL  ; p = strtok(NULL, " "))
        {   
            
            if(strlen(p)==0|| strcmp(p," ")==0 ||strcmp(p,"\0")==0 ||p[0]==10||p[0]==9)
            {
            
                continue;
            }
            
            
            strcpy(str[index],p);
            len++;
            index++;
        }
   
        if(len==1)
        {
            
            char *p=strtok(str[0],"\n");
      
            if(strcmp(p,"pwd")==0)
                parent();
            else if(strcmp(p,"pinfo")==0)
            {
                char emp[20];
                pinfo(emp);
            } 
            else if(strcmp(p,"cd")==0)
            {

                chdir(path_name);
            }  
            else if(strcmp(p,"ls")==0)
            {
                char s_1[20];
                char s_2[20];
                s_1[0]='\0';
                s_2[0]='\0';
                ls(s_1,s_2);
              
            } 
           else
            {
               
                char s_1[20];
                s_1[0]='\0';
                fg(p,s_1,0);
            }
            continue;

        }
        else if(len>=2)
        {
            char *p=strtok(str[0],"\n");
            if(strcmp(p,"echo")==0)
            {   
                for(int j=1;j<len;j++)
                {
                    
                    char *q=strtok(str[j],"\n");
                    printf("%s ",q);
                }
                printf("\n");
                continue;
                
            }
            if(len==3 && strcmp(p,"ls")==0)
            {
                char *q_1=strtok(str[1],"\n");
                char *q_2=strtok(str[2],"\n");
                ls(q_1,q_2);
            }
            if(len==3)
            {
                
                char *q_1=strtok(str[1],"\n");
                char *q_2=strtok(str[2],"\n");
                if(strcmp(q_2,"&")==0)
                {
                   
                    fg(p,q_1,1);
                } 
            }
            if(len==2)
            {
                char *h=strtok(str[1],"\n");
                if(strcmp(p,"cd")==0)
                {
                  
                    
                    char *q=strtok(str[1],"\n");
                    if(strcmp(q,"~")==0)
                    {
                        chdir(path_name);  
                    }
                    else if(q[0]=='~')
                    {
                        char res[2000];
                        int i;
                        strcpy(res,path_name);
                    

                        for( i=1;i<strlen(q);i++)
                        {
                            
                            strncat(res,&q[i],1);
                        }
                        
                
                        chdir(res);
                    }
                    else
                    chdir(q);

                }
                else if(strcmp(p,"pinfo")==0)
                {
                    char *q=strtok(str[1],"\n");
                    pinfo(q);
                }
                else if(strcmp(p,"ls")==0)
                {
                    
                    char *q=strtok(str[1],"\n");
                   
                    char s_r[20];
                    s_r[0]='\0';
                    if(q[0]=='-')
                    {
                     
                        ls(q,s_r);
                    }
                    else
                    {
                       
                        ls(s_r,q);
                    }
                    
                   
                }
                else
                {
                  
                    fg(p,h,0);
                }
                                

            }
        }
        else
        {
         
            return 0;
        }
        
    }
    return 0;

}